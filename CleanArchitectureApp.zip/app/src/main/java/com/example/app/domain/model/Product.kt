package com.example.app.domain.model

data class Product(val id: Long, val name: String, val price: Double)